I'm Tanish Hupare. README file for assignment-3 smallish

1. Use cd and ls to navigate your way into the correct directory in the terminal. 
2. To run the code first compile the program by typing "gcc -std=c99 smallsh.c -o smallsh" into the terminal and press enter. 
3. After that run the executable and enter the command ./smallsh.
4. Finally the program will start running and you can follow what the prompt tells you to navigate 
